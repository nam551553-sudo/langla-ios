package com.beatdz.langlalau;
import android.os.Bundle;
import com.badlogic.gdx.backends.android.*;
import com.boot.GameM;
import com.boot.MobilePlatform;
public class AndroidLauncher extends AndroidApplication {
    private AndroidUpdates updates;
    private DisplayFrames frames;
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        updates=new AndroidUpdates(this);
        MobilePlatform.install();
        AndroidApplicationConfiguration config = new AndroidApplicationConfiguration();
        config.r = config.g = config.b = config.a = 8;
        config.depth = config.stencil = config.numSamples = 0;
        config.useAccelerometer = config.useGyroscope = config.useCompass = config.useRotationVectorSensor = false;
        initialize(GameM.l(), config);
        frames = new DisplayFrames(this, graphics.getView());
        updates.check();
    }
    @Override protected void onResume(){super.onResume();if(frames!=null)frames.start();if(updates!=null)updates.resume();}
    @Override protected void onPause(){if(frames!=null)frames.stop();super.onPause();}
    @Override protected void onDestroy(){if(frames!=null)frames.stop();super.onDestroy();}
}
