package beatdz;

import java.io.IOException;
import java.util.Arrays;
import java.util.Vector;
import java.util.concurrent.atomic.AtomicInteger;

public final class EquipmentRefinementScreen extends LangLa_kj {
    public static final int CHANNEL = 126;
    private static final int DISPLACE = 1;
    private static final int COLUMNS = 4;
    private static final int CELL = 32;
    private static final int EXECUTE = 7100, INSPECT = 7101;
    private static final int EQUIPMENT = 7200, RESULT = 7201, STONES = 7202;
    // LangLa_ch forwards confirmation clicks as UI events for actions 2000–3000.
    private static final int CONFIRM = 2001;
    private static final AtomicInteger REQUEST_IDS = new AtomicInteger();
    private static final String CHOOSE_EQUIPMENT = "Chọn trang bị trong tab Túi.";

    private final int mode;
    private final int materialRows;
    private final LangLa_ij equipmentCell, resultCell, materialGrid;
    private final Item[] materialCells;
    private Item selected, preview;
    private int selectedSlot = -1;
    private int requestId, materialId, quantity, fee, chance, materialCount;
    private long nonce, confirmationNonce, submittedAt;
    private String details = CHOOSE_EQUIPMENT;
    private String problem = "";
    private boolean pending;

    public EquipmentRefinementScreen(MainScreen parent, int mode) {
        super(parent, new String[]{mode == DISPLACE ? "Dịch chuyển" : "Tinh luyện", "Trang bị"});
        this.mode = mode;
        materialRows = mode == DISPLACE ? 5 : 4;
        materialCells = new Item[materialRows * COLUMNS];
        equipmentCell = new LangLa_ij((byte) 1, 162, a_() + 16, CELL, CELL, CELL, 1, 1);
        resultCell = new LangLa_ij((byte) 1, 242, a_() + 16, CELL, CELL, CELL, 1, 1);
        materialGrid = new LangLa_ij((byte) 1, 14, a_() + 20, COLUMNS * CELL,
                materialRows * CELL, CELL, materialRows, COLUMNS);
        a(a(width - 70, height - 33, title(), this, EXECUTE, -8), 0);
        a(a(162, height - 33, "Xem trước", this, INSPECT, -8), 0);
    }

    private String title() {
        return mode == DISPLACE ? "Dịch chuyển" : "Tinh luyện";
    }

    private Message request(int operation) throws IOException {
        Message message = new Message((byte) 122);
        message.writeByte(CHANNEL);
        message.writeByte(operation);
        message.writeInt(requestId);
        return message;
    }

    private void select(Item item, int slot) {
        if (pending || item == null) return;
        ItemTemplate template = item.getItemTemplate();
        if (template == null || template.type < 0 || template.type > 9) {
            p.showMessage("Chọn trang bị cơ bản trong hành trang.", -65536);
            return;
        }
        clearSelection();
        selected = item;
        selectedSlot = slot;
        problem = "Đang lấy báo giá…";
        try {
            Message message = request(1);
            message.writeShort(slot);
            message.send();
            a(0);
        } catch (IOException error) {
            problem = "Không gửi được yêu cầu.";
            p.showMessage(problem, -65536);
        }
    }

    private void clearSelection() {
        requestId = REQUEST_IDS.incrementAndGet();
        selected = preview = null;
        selectedSlot = -1;
        materialId = quantity = fee = chance = 0;
        nonce = confirmationNonce = 0;
        problem = "";
        details = CHOOSE_EQUIPMENT;
        refreshMaterials();
    }

    private void refreshMaterials() {
        Arrays.fill(materialCells, null);
        materialCount = 0;
        if (quantity == 0) return;
        long now = System.currentTimeMillis();
        // Fill one cell per unit, in the same bag order as the server's debit.
        for (Item item : Char.gI().arrItemBag) {
            if (item == null || item.id != materialId || (item.expiry != -1 && item.expiry <= now)) continue;
            int count = Math.min(item.getAmount(), quantity - materialCount);
            // Use a display copy so a stack of 20 does not print 20 on every cell.
            Item unit = new Item(item.id);
            unit.isLock = item.isLock;
            Arrays.fill(materialCells, materialCount, materialCount + count, unit);
            materialCount += count;
            if (materialCount == quantity) break;
        }
    }

    @Override public void a() {
        t = Char.gI().arrItemBag;
    }

    @Override public void b() {
        super.b();
        equipmentCell.a();
        resultCell.a();
        materialGrid.a();
        if (pending && System.currentTimeMillis() - submittedAt > 15000) {
            pending = false;
            clearSelection();
            p.showMessage("Chưa nhận kết quả. Hãy kiểm tra túi rồi chọn lại trang bị.", -65536);
        } else if (!pending && selectedSlot >= 0) {
            Item[] bag = Char.gI().arrItemBag;
            if (selectedSlot >= bag.length || bag[selectedSlot] != selected) clearSelection();
        }
    }

    @Override public void a(Graphics graphics) {
        super.a(graphics);
        if (k() != 0) return;

        mFont.b(mFont.d, graphics, "Đặt đá và trang bị", 14, a_() + 9, 0, -10831436, -16777216);
        a(graphics, equipmentCell.cx, equipmentCell.cy, selected, equipmentCell.k >= 0, "Trang bị");
        a(graphics, resultCell.cx, resultCell.cy, preview, resultCell.k >= 0, "Xem thử");
        LangLa_fq.a(graphics, 95, 0, 210, a_() + 25, 20);

        int right = 216;
        if (pending) {
            mFont.b(mFont.d, graphics, "Đang thực hiện…", right, a_() + 62, 2, -1, -16777216);
        } else if (quantity > 0) {
            mFont.b(mFont.d, graphics, "Đá " + materialCount + "/" + quantity,
                    right, a_() + 62, 2, materialCount == quantity ? -1 : -65536, -16777216);
            mFont.b(mFont.d, graphics, "Tỉ lệ " + chance + "%", right, a_() + 77, 2, -1, -16777216);
            mFont.b(mFont.d, graphics, "Phí " + Utlis.numberFormat(fee) + " bạc",
                    right, a_() + 92, 2, -1, -16777216);
        } else {
            mFont.b(mFont.d, graphics, "Chọn trang bị trong Túi", right, a_() + 62, 2, -1, -16777216);
        }

        a(graphics, materialGrid);
        for (int row = 0; row < materialRows; row++) {
            for (int column = 0; column < COLUMNS; column++) {
                int index = row * COLUMNS + column;
                b(graphics, column * CELL, row * CELL, materialCells[index], materialGrid.k == index, "Đá");
            }
        }
        b(graphics);
    }

    @Override public Vector c() {
        Vector regions = super.c();
        if (k() == 0) {
            regions.addElement(equipmentCell.a(EQUIPMENT, this));
            regions.addElement(resultCell.a(RESULT, this));
            regions.addElement(materialGrid.a(STONES, this));
        }
        return regions;
    }

    @Override public void a(LangLa_jz event, int x, int y) {
        if (k() == j() && event.b == 5001) {
            int slot = event.j.k;
            if (slot >= 0 && slot < t.length) select(t[slot], slot);
            return;
        }
        if (k() == 0) {
            switch (event.b) {
                case CONFIRM:
                    commit();
                    return;
                case EXECUTE:
                    askToCommit();
                    return;
                case INSPECT:
                case RESULT:
                    p.a((LangLa_cx) new ReleaseNotesDialog(p, "Xem trước " + title().toLowerCase(java.util.Locale.ROOT), details));
                    return;
                case EQUIPMENT:
                    a(j());
                    return;
                case STONES:
                    showMaterial();
                    return;
                default:
                    break;
            }
        }
        super.a(event, x, y);
    }

    private void showMaterial() {
        if (quantity == 0) return;
        refreshMaterials();
        ItemTemplate stone = new Item(materialId).getItemTemplate();
        String name = stone == null ? "nguyên liệu" : stone.name;
        p.showMessage(materialCount + "/" + quantity + " " + name + " lấy từ Túi.", -1);
    }

    private void askToCommit() {
        if (pending) return;
        if (nonce == 0 || selected == null) {
            p.showMessage(problem.isEmpty() ? CHOOSE_EQUIPMENT : problem, -65536);
            return;
        }
        refreshMaterials();
        if (materialCount < quantity) {
            p.showMessage("Cần thêm " + (quantity - materialCount) + " viên đá phù hợp.", -65536);
            return;
        }
        confirmationNonce = nonce;
        String cost = "Cần " + quantity + " viên đá. Phí " + Utlis.numberFormat(fee) + " bạc.";
        String warning = mode == DISPLACE ? "Chỉ số sẽ được quay khi xác nhận."
                : "Trừ bạc khóa trước. Thất bại vẫn mất đá và bạc.";
        p.a(title() + " trang bị?\n" + cost + "\n" + warning, CONFIRM, this);
    }

    private void commit() {
        if (pending || nonce == 0 || confirmationNonce != nonce) return;
        if (!Session.gI().isConnected()) {
            clearSelection();
            p.showMessage("Đã mất kết nối. Hãy vào lại game và chọn trang bị.", -65536);
            return;
        }
        try {
            Message message = request(2);
            message.writeLong(nonce);
            pending = true;
            submittedAt = System.currentTimeMillis();
            nonce = confirmationNonce = 0;
            message.send();
        } catch (IOException error) {
            pending = false;
            clearSelection();
            p.showMessage("Chưa gửi được thao tác. Hãy chọn lại trang bị.", -65536);
        }
    }

    void accept(int operation, Message message) throws IOException {
        if (message.readInt() != requestId) return;
        boolean ok = message.readBoolean();
        String text = message.readUTF();
        if (operation == 1 && ok) {
            nonce = message.readLong();
            materialId = message.readShort();
            quantity = message.readShort();
            fee = message.readInt();
            chance = message.readByte();
            details = message.readUTF();
            Item result = new Item();
            result.read(message);
            if (mode == DISPLACE) {
                // Older servers send a minimum-roll sample in this field. Show only the source icon
                // and open the authoritative range text when the player inspects the result.
                preview = selected;
                details += "\nMỗi dòng có khoảng sẽ được quay riêng khi xác nhận.";
            } else {
                preview = result;
            }
            problem = "";
            refreshMaterials();
            return;
        }
        pending = false;
        clearSelection();
        if (operation == 2) {
            p.a((LangLa_cx) new ReleaseNotesDialog(p, ok ? "Thành công" : "Kết quả tinh luyện", text));
        } else {
            p.showMessage(text, -65536);
        }
    }

    public static void receive(GameSrc game, Message message) throws IOException {
        int operation = message.readByte();
        if (operation == 0) {
            message.readInt();
            game.a((LangLa_cx) new EquipmentRefinementScreen(game, message.readByte()));
            return;
        }
        for (int i = game.cD.size() - 1; i >= 0; i--) {
            Object panel = game.cD.get(i);
            if (panel instanceof EquipmentRefinementScreen) {
                ((EquipmentRefinementScreen) panel).accept(operation, message);
                return;
            }
        }
    }
}
