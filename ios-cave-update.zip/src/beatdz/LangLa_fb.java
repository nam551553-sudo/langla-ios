package beatdz;
import java.util.Hashtable;

public class LangLa_fb {
   public short a;
   public int b;
   public int c;
   public String d;
   public String e;
   public volatile boolean f;
   public Hashtable g;
   boolean imageCacheEntry;
   int sourceZoom;
   byte[] download;
   String downloadUrl;

   public boolean a() {
      return this.d.contains("arr_data_game");
   }

   public boolean b() {
      return this.d.contains("jasr.dll");
   }

   public boolean c() {
      return this.d.contains("LangLa.exe");
   }

   public boolean d() {
      return this.d.contains("core.jar");
   }

   public boolean e() {
      return this.d.contains("gdx.jar");
   }
}
