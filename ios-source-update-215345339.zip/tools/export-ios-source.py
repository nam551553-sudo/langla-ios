from pathlib import Path
import sys,zipfile
root=Path(__file__).resolve().parent.parent
folders=['src','resource','music','sound','support','DanhHieu','ios','android','core','desktop','launcher','gradle','tools/ci','.github']
with zipfile.ZipFile(sys.argv[1],'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for folder in folders:
  for f in (root/folder).rglob('*'):
   if f.is_file() and not {'build','.gradle','__pycache__'}.intersection(f.relative_to(root).parts) and f.suffix not in {'.pk8','.pem','.jks','.keystore'}:
    z.write(f,f.relative_to(root))
 for name in ['build.gradle','settings.gradle','gradle.properties','gradlew','gradlew.bat','version.properties','release-config.json','UPDATE-VERSION.md','README-GITHUB-IOS.md','tools/export-ios-source.py','tools/prepare-blue-icons.py']:
  f=root/name
  if f.exists():z.write(f,name)
