package com.beatdz.langlalau;
import android.app.*;import android.content.*;import android.content.pm.*;import android.net.Uri;import android.os.Build;import android.provider.Settings;import java.io.*;import java.net.*;import java.security.*;import java.util.*;import org.json.*;
/** version.json update flow from Combo_Vip/client, with size/hash and signing checks. */
final class AndroidUpdates {
 static final String BASE=com.langla.config.Endpoints.UPDATE_BASE;
 final Activity activity;File pending;
 AndroidUpdates(Activity activity){this.activity=activity;}
 static InputStream open(String url)throws Exception{URLConnection c=new URL(url).openConnection();c.setConnectTimeout(5000);c.setReadTimeout(20000);c.setUseCaches(false);return c.getInputStream();}
 void check(){new Thread(()->{try{
  JSONObject next;try(InputStream in=open(BASE+"version.json?t="+System.currentTimeMillis())){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);next=new JSONObject(out.toString("UTF-8")).getJSONObject("android");}
  if(next.getInt("versionCode")<=activity.getPackageManager().getPackageInfo(activity.getPackageName(),0).versionCode)return;
  activity.runOnUiThread(()->new AlertDialog.Builder(activity).setTitle("Cập nhật Làng Lá Blue").setMessage("Đã có bản mới. Tải và cập nhật game?").setNegativeButton("Để sau",null).setPositiveButton("Cập nhật",(d,w)->download(next)).show());
 }catch(Exception e){android.util.Log.w("LangLaUpdate","Update check failed",e);}},"version-check").start();}
 void download(JSONObject next){ProgressDialog dialog=new ProgressDialog(activity);dialog.setMessage("Đang tải bản cập nhật…");dialog.setCancelable(false);dialog.show();new Thread(()->{try{
  File root=new File(activity.getFilesDir(),"updates/packages");root.mkdirs();File temp=new File(root,"download.part"),apk=new File(root,next.getInt("versionCode")+".apk");MessageDigest hash=MessageDigest.getInstance("MD5");long size=0;
  try(InputStream in=open(new URL(new URL(BASE),next.getString("apkUrl")).toString());OutputStream out=new FileOutputStream(temp)){byte[] b=new byte[65536];int n;while((n=in.read(b))!=-1){out.write(b,0,n);hash.update(b,0,n);size+=n;}}
  StringBuilder digest=new StringBuilder();for(byte b:hash.digest())digest.append(String.format("%02x",b&255));
  if(size!=next.getLong("apkSize")||!digest.toString().equalsIgnoreCase(next.getString("apkMd5"))){temp.delete();throw new IOException("APK size/hash mismatch");}
  if(apk.exists()&&!apk.delete())throw new IOException("Cannot replace APK");if(!temp.renameTo(apk))throw new IOException("Cannot save APK");install(apk);
 }catch(Exception e){activity.runOnUiThread(()->new AlertDialog.Builder(activity).setMessage("Không cập nhật được: "+e.getMessage()).setPositiveButton("OK",null).show());}finally{activity.runOnUiThread(dialog::dismiss);}},"apk-download").start();}
 @SuppressWarnings("deprecation") static Set<String> signatures(PackageInfo p){Set<String> result=new HashSet<>();android.content.pm.Signature[] a=Build.VERSION.SDK_INT>=28&&p.signingInfo!=null?p.signingInfo.getApkContentsSigners():p.signatures;if(a!=null)for(android.content.pm.Signature s:a)result.add(s.toCharsString());return result;}
 @SuppressWarnings("deprecation") void install(File apk)throws Exception{
  PackageManager pm=activity.getPackageManager();int flags=Build.VERSION.SDK_INT>=28?PackageManager.GET_SIGNING_CERTIFICATES:PackageManager.GET_SIGNATURES;
  PackageInfo next=pm.getPackageArchiveInfo(apk.toString(),flags),old=pm.getPackageInfo(activity.getPackageName(),flags);
  if(next==null||!old.packageName.equals(next.packageName)||signatures(next).isEmpty()||!signatures(old).equals(signatures(next))||next.versionCode<=old.versionCode)throw new IOException("APK identity/version mismatch");
  pending=apk;activity.runOnUiThread(()->{if(Build.VERSION.SDK_INT>=26&&!pm.canRequestPackageInstalls())activity.startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+activity.getPackageName())));else resume();});
 }
 void resume(){if(pending==null||(Build.VERSION.SDK_INT>=26&&!activity.getPackageManager().canRequestPackageInstalls()))return;Uri uri=Uri.parse("content://"+activity.getPackageName()+".updates/apk/"+pending.getName());pending=null;activity.startActivity(new Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));}
}
