package beatdz;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

/** Optional desktop artwork preview. Releases without a local override use the normal asset service. */
final class WeaponReviewAssets {
    private static final Path ROOT = previewDirectory();
    private static final Map<Integer, float[]> GRIPS = readGrips();

    private static Path previewDirectory() {
        String folder = System.getProperty("langla.weaponPreviewDir", "");
        return folder.trim().isEmpty() ? null : Paths.get(folder).toAbsolutePath().normalize();
    }

    private static Map<Integer, float[]> readGrips() {
        Map<Integer, float[]> points = new HashMap<>();
        if (ROOT == null) return points;
        try {
            for (String line : Files.readAllLines(ROOT.resolve("grips.csv"))) {
                String[] fields = line.split(",");
                int id = Integer.parseInt(fields[0]);
                points.put(id, new float[]{Float.parseFloat(fields[2]), Float.parseFloat(fields[3])});
            }
        } catch (java.io.IOException failure) {
            throw new IllegalStateException("Missing weapon preview hand positions", failure);
        }
        return points;
    }

    static float[] grip(int icon) { return GRIPS.get(icon); }
    static boolean has(int icon) { return GRIPS.containsKey(icon); }

    static mImage image(LangLa_fb request) {
        if (ROOT == null || request.d == null || !request.d.matches("icon(?:Char|Client)/[0-9]+\\.png")) return null;
        int zoom = request.sourceZoom > 0 ? request.sourceZoom : DataCenter.a(request.d) + 1;
        Path asset = ROOT.resolve("zoom" + zoom).resolve(request.d);
        if (!Files.isRegularFile(asset)) return null;
        try { return Binary.createImage(Files.readAllBytes(asset)); }
        catch (java.io.IOException failure) { throw new IllegalStateException("Cannot load weapon preview " + request.d, failure); }
    }
}
