package beatdz;
import java.util.Vector;

/** Uses the same wooden equipment/bag tabs and item cells as enhancement. No speculative bag edits. */
public final class EquipmentRefinementScreen extends LangLa_kj {
 public static final int CHANNEL=126;
 private final int mode;private final LangLa_ij[] cells=new LangLa_ij[3];
 private Item selected,preview,material;private int selectedSlot=-1,requestId,quantity,fee,chance;
 private long nonce,submittedAt;private String details="Chọn trang bị trong tab Túi.",problem="";private boolean pending;
 private LangLa_dz execute,inspect;
 public EquipmentRefinementScreen(MainScreen parent,int mode){super(parent,new String[]{mode==1?"Dịch chuyển":"Tinh luyện","Trang bị"});this.mode=mode;
  cells[0]=new LangLa_ij((byte)1,45,a_()+28,32,32,32,1,1);cells[1]=new LangLa_ij((byte)1,218,a_()+28,32,32,32,1,1);cells[2]=new LangLa_ij((byte)1,131,a_()+83,32,32,32,1,1);
  execute=a(width-82,height-33,mode==1?"Dịch chuyển":"Tinh luyện",this,7100,-8);a(execute,0);inspect=a(8,height-33,"Xem trước",this,7101,-8);a(inspect,0);
 }
 private Message request(int op)throws Exception{Message m=new Message((byte)122);m.writeByte(CHANNEL);m.writeByte(op);m.writeInt(requestId);return m;}
 private void select(Item item){if(pending)return;if(item==null||item.getItemTemplate().type<0||item.getItemTemplate().type>9){p.showMessage("Hãy chọn trang bị cơ bản trong hành trang.",-65536);return;}selected=item;selectedSlot=item.index;preview=null;material=null;nonce=0;problem="Đang lấy báo giá…";requestId++;try{Message m=request(1);m.writeShort(selectedSlot);m.send();a(0);}catch(Exception e){problem="Không gửi được yêu cầu.";}}
 @Override public void a(){t=Char.gI().arrItemBag;}
 @Override public void b(){super.b();for(LangLa_ij cell:cells)if(cell!=null)cell.a();if(pending&&System.currentTimeMillis()-submittedAt>15000){pending=false;nonce=0;problem="Chưa nhận kết quả. Hãy chọn lại trang bị để kiểm tra.";}if(selectedSlot>=0&&!pending&&Char.gI().arrItemBag[selectedSlot]!=selected){selected=null;preview=null;material=null;nonce=0;}}
 @Override public void a(Graphics g){super.a(g);if(k()!=0)return;
  a(g,cells[0].cx,cells[0].cy,selected,cells[0].k>=0,"Trang bị");a(g,cells[1].cx,cells[1].cy,preview,cells[1].k>=0,"Xem thử");a(g,cells[2].cx,cells[2].cy,material,cells[2].k>=0,"Nguyên liệu");LangLa_fq.a(g,95,0,144,a_()+34,20);
  mFont.c(mFont.d,g,"Đặt trang bị và nguyên liệu",width/2,a_()+9,2,-10831436,-16777216);
  String line=selected==null?"Chọn trang bị trong tab Túi":pending?"Đang thực hiện…":problem.length()>0?problem:"Tỉ lệ: "+chance+"% | Cần: "+quantity+" viên";
  mFont.c(mFont.d,g,line,width/2,a_()+128,2,-1,-16777216);mFont.c(mFont.d,g,"Phí: "+Utlis.numberFormat(fee)+" bạc (ưu tiên bạc khóa)",width/2,a_()+143,2,-1,-16777216);
 }
 @Override public Vector c(){Vector v=super.c();if(k()==0)for(int i=0;i<cells.length;i++)v.addElement(cells[i].a(7200+i,this));return v;}
 @Override public void a(LangLa_jz event,int x,int y){
  if(k()==j()&&event.b==5001){if(event.j.k>=0&&event.j.k<t.length)select(t[event.j.k]);return;}
  if(k()==0){if(event.b==7100){if(!pending&&nonce!=0&&selected!=null)p.a("Cần "+quantity+" viên và "+Utlis.numberFormat(fee)+" bạc. Tỉ lệ "+chance+"%.\n"+(mode==2?"Thất bại vẫn mất nguyên liệu và bạc.\n":"")+"Xác nhận thực hiện?",7300,this);else p.showMessage(problem.length()>0?problem:"Hãy chọn trang bị và xem trước.",-65536);return;}
   if(event.b==7101||event.b==7201){p.a((LangLa_cx)new ReleaseNotesDialog(p,"Xem trước "+(mode==1?"dịch chuyển":"tinh luyện"),details));return;}
   if(event.b==7200){a(j());return;}if(event.b==7202){findMaterial();return;}
  }super.a(event,x,y);
 }
 @Override public void a(int action,Object value,LangLa_cy source){if(action==7300){if(pending||nonce==0)return;try{Message m=request(2);m.writeLong(nonce);pending=true;submittedAt=System.currentTimeMillis();nonce=0;m.send();}catch(Exception e){pending=false;problem="Chưa gửi được thao tác. Hãy chọn lại trang bị.";}return;}super.a(action,value,source);}
 private void findMaterial(){material=null;int id=mode==1?1153:materialId;for(Item item:Char.gI().arrItemBag)if(item!=null&&item.id==id){material=item;break;}}
 private int materialId;
 void accept(int op,Message m)throws Exception{int response=m.readInt();if(response!=requestId)return;
  boolean ok=m.readBoolean();String text=m.readUTF();if(op==1){if(!ok){nonce=0;problem=text;return;}nonce=m.readLong();materialId=m.readShort();quantity=m.readShort();fee=m.readInt();chance=m.readByte();details=m.readUTF();preview=new Item();preview.read(m);findMaterial();problem="";}else{pending=false;nonce=0;preview=null;problem=text;selected=null;selectedSlot=-1;material=null;p.a((LangLa_cx)new ReleaseNotesDialog(p,op==2?(ok?"Thành công":"Kết quả tinh luyện"):"Thông báo",text));}
 }
 public static void receive(GameSrc game,Message m)throws Exception{int op=m.readByte();if(op==0){m.readInt();game.a((LangLa_cx)new EquipmentRefinementScreen(game,m.readByte()));return;}for(int i=game.cD.size()-1;i>=0;i--){Object p=game.cD.get(i);if(p instanceof EquipmentRefinementScreen){((EquipmentRefinementScreen)p).accept(op,m);return;}}}
}
