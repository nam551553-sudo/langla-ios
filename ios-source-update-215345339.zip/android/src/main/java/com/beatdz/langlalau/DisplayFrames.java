package com.beatdz.langlalau;

import android.app.Activity;
import android.os.Build;
import android.view.Choreographer;
import android.view.Display;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import com.badlogic.gdx.Gdx;
import beatdz.FrameCadence;

/** Request complete GL frames at a stable display divisor, capped at 60, without swapping skipped frames. */
final class DisplayFrames implements Choreographer.FrameCallback {
    private final Activity activity;
    private final View view;
    private boolean running;
    private final FrameCadence cadence = new FrameCadence();

    DisplayFrames(Activity activity, View view) { this.activity = activity; this.view = view; }

    void start() {
        if (running) return;
        prefer60Hz();
        running = true; cadence.reset();
        Gdx.graphics.setContinuousRendering(false);
        Choreographer.getInstance().postFrameCallback(this);
    }

    void stop() {
        running = false;
        Choreographer.getInstance().removeFrameCallback(this);
    }

    private void prefer60Hz() {
        try {
            Display display = activity.getWindowManager().getDefaultDisplay();
            WindowManager.LayoutParams params = activity.getWindow().getAttributes();
            params.preferredRefreshRate = 60f;
            if (Build.VERSION.SDK_INT >= 23) {
                Display.Mode current = display.getMode(), best = null;
                for (Display.Mode mode : display.getSupportedModes()) {
                    if (mode.getPhysicalWidth() != current.getPhysicalWidth()
                            || mode.getPhysicalHeight() != current.getPhysicalHeight()) continue;
                    if (mode.getRefreshRate() > 60.5f || mode.getRefreshRate() < 30f) continue;
                    if (best == null || mode.getRefreshRate() > best.getRefreshRate()) best = mode;
                }
                if (best != null) params.preferredDisplayModeId = best.getModeId();
            }
            activity.getWindow().setAttributes(params);
            if (Build.VERSION.SDK_INT >= 30 && view instanceof SurfaceView) {
                android.view.Surface surface = ((SurfaceView)view).getHolder().getSurface();
                if (surface.isValid()) surface.setFrameRate(60f, android.view.Surface.FRAME_RATE_COMPATIBILITY_DEFAULT);
            }
        } catch (RuntimeException ignored) {
            // Some OEMs reject display mode hints. The vsync divisor remains available.
        }
    }

    @Override public void doFrame(long frameTimeNanos) {
        if (!running) return;
        float refresh = activity.getWindowManager().getDefaultDisplay().getRefreshRate();
        if (cadence.next(refresh)) Gdx.graphics.requestRendering();
        Choreographer.getInstance().postFrameCallback(this);
    }
}
