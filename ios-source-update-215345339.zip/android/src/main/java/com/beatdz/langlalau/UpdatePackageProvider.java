package com.beatdz.langlalau;
import android.content.*;import android.database.*;import android.net.Uri;import android.os.ParcelFileDescriptor;import android.provider.OpenableColumns;import java.io.*;import java.util.*;

public final class UpdatePackageProvider extends ContentProvider {
    private File file(Uri uri)throws FileNotFoundException{
        try{List<String> parts=uri.getPathSegments();if(parts.size()!=2||!parts.get(0).equals("apk")||!parts.get(1).matches("[0-9]+\\.apk"))throw new IOException();
            File root=new File(getContext().getFilesDir(),"updates/packages").getCanonicalFile(),file=new File(root,parts.get(1)).getCanonicalFile();
            if(!root.equals(file.getParentFile())||!file.isFile())throw new IOException();return file;
        }catch(IOException e){throw new FileNotFoundException("Update APK not found");}
    }
    @Override public boolean onCreate(){return true;}
    @Override public String getType(Uri uri){return "application/vnd.android.package-archive";}
    @Override public ParcelFileDescriptor openFile(Uri uri,String mode)throws FileNotFoundException{if(!"r".equals(mode))throw new FileNotFoundException("Read-only provider");return ParcelFileDescriptor.open(file(uri),ParcelFileDescriptor.MODE_READ_ONLY);}
    @Override public Cursor query(Uri uri,String[] projection,String selection,String[] args,String order){try{File file=file(uri);MatrixCursor cursor=new MatrixCursor(new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE});cursor.addRow(new Object[]{"LangLaBlue.apk",file.length()});return cursor;}catch(FileNotFoundException e){return null;}}
    @Override public Uri insert(Uri uri,ContentValues values){throw new UnsupportedOperationException();}
    @Override public int delete(Uri uri,String selection,String[] args){throw new UnsupportedOperationException();}
    @Override public int update(Uri uri,ContentValues values,String selection,String[] args){throw new UnsupportedOperationException();}
}
