package beatdz;

import com.badlogic.gdx.Gdx;
import java.net.URI;

/** Client for the server's existing bank top-up events; never credits currency locally. */
public final class GoldTopUpPanel extends LangLa_fo {
    @Override public void a(int event, Object value) { }
    @Override public void a(int event, Object value, LangLa_cy source) { }
    @Override public void b() { tiers.b(); }
    private final LangLa_cg tiers;
    private String details = "Chọn mốc nạp rồi nhấn Tạo QR.\nTiền được cộng vào số dư web theo thông tin server.";
    private String url;
    private String status = "";
    private mImage qr;
    private long requestedAt;
    private int generation;
    private boolean closed;

    public GoldTopUpPanel(MainScreen screen) {
        p = screen;
        cF = 2;
        a(360, 275);
        tiers = a(12, 32, 225, 4, new LangLa_kd(2000, new String[]{
            "10.000 đ", "50.000 đ", "100.000 đ", "200.000 đ", "500.000 đ",
            "1.000.000 đ", "2.000.000 đ", "5.000.000 đ", "10.000.000 đ"}), this, 0);
        tiers.a(0);
        a(250, 32, "Tạo QR", this, 2001, -8).setSize(96, 22);
        a(12, 242, "Mở QR", this, 2002, -8).setSize(96, 22);
        a(121, 242, "Sao chép", this, 2003, -8).setSize(96, 22);
    }

    static boolean validQrUrl(String value) {
        try {
            URI uri = new URI(value);
            if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getUserInfo() != null
                    || uri.getFragment() != null || (uri.getPort() != -1 && uri.getPort() != 443)) return false;
            if ("img.vietqr.io".equalsIgnoreCase(uri.getHost())) return true;
            URI base = new URI(ClientConfig.DATA_URL);
            URI endpoint = base.resolve("charge/bank-qr.php");
            return base.getHost() != null && base.getHost().equalsIgnoreCase(uri.getHost())
                && endpoint.getRawPath().equals(uri.getRawPath())
                && (uri.getRawQuery() == null || uri.getRawQuery().matches("ref=LLDC[A-F0-9]{16}"));
        } catch (Exception e) { return false; }
    }

    public void receive(String title, String text, String imageUrl) {
        requestedAt = 0;
        details = text == null ? "" : text;
        // The legacy compact string encoder replaces newlines with spaces.
        for (String field : new String[]{"MBBank:", "Số tiền:", "Nhận:", "Nội dung:", "Lệnh có hiệu lực", "Chưa bật auto bank"})
            details = details.replace(" " + field, "\n" + field);
        url = validQrUrl(imageUrl) ? imageUrl : null;
        final int ticket = ++generation;
        if (qr != null) { qr.a(); qr = null; }
        status = url == null ? "QR không hợp lệ" : "Đang tải QR...";
        if (url == null) return;
        final String source = url;
        Thread worker = new Thread(MultiSession.bind(() -> {
            byte[] result = null;
            try {
                byte[] bytes = HttpDownloads.bytes(source, 15000, 2 * 1024 * 1024);
                if (validQrPng(bytes)) result = bytes;
            } catch (Exception ignored) {
                // The browser fallback remains available; never log payment references or URLs.
            }
            final byte[] image = result;
            Gdx.app.postRunnable(MultiSession.bind(() -> {
                if (closed || generation != ticket) return;
                if (image != null) qr = mImage.a(image, 0, image.length);
                status = qr == null ? "Không tải được QR; chọn Mở QR" : "";
            }));
        }), "topup-qr");
        worker.setDaemon(true);
        worker.start();
    }

    @Override public void a(Graphics graphics) {
        a(graphics, cx, cy, width, height, "Nạp Coin", (byte)2, false);
        if (qr != null) {
            int size = 142;
            float scale = Math.min((float)size / qr.c, (float)size / qr.d);
            int w = Math.max(1, Math.round(qr.c * scale));
            int h = Math.max(1, Math.round(qr.d * scale));
            graphics.a(qr, 0, 0, qr.c, qr.d, 0, 12 + (size - w) / 2, 66 + (size - h) / 2,
                w * DataCenter.gI().zoomLevel, h * DataCenter.gI().zoomLevel, 0);
        }
        int y = 65;
        for (String paragraph : details.split("\n")) {
            for (String line : mFont.c(mFont.d, paragraph, 187)) {
                if (y > 225) break;
                mFont.b(mFont.d, graphics, line, 163, y, 0, -1, -16777216);
                y += 12;
            }
        }
        String message = requestedAt != 0
            ? (System.currentTimeMillis() - requestedAt < 15000 ? "Đang yêu cầu server..." : "Chưa nhận QR. Kiểm tra thông báo server rồi thử lại.") : status;
        mFont.b(mFont.d, graphics, message, 12, 223, 0, -2560, -16777216);
    }

    @Override public void a(LangLa_jz event, int x, int y) {
        try {
            if (event.b == 2001) {
                if (requestedAt != 0 && System.currentTimeMillis() - requestedAt < 15000) return;
                Message request = new Message((byte)122);
                request.writeByte(127);
                request.writeByte(tiers.b.b);
                request.send();
                requestedAt = System.currentTimeMillis();
            } else if (event.b == 2002 && url != null) Gdx.net.openURI(url);
            else if (event.b == 2003) Gdx.app.getClipboard().setContents(details);
        } catch (Exception ignored) { status = "Không thể gửi yêu cầu. Vui lòng thử lại."; requestedAt = 0; }
    }

    @Override public void d() {
        closed = true;
        ++generation;
        if (qr != null) { qr.a(); qr = null; }
    }

    static boolean validQrPng(byte[] bytes) {
        if (bytes == null || bytes.length < 24 || bytes[0] != (byte)137 || bytes[1] != 80
                || bytes[2] != 78 || bytes[3] != 71 || bytes[4] != 13 || bytes[5] != 10
                || bytes[6] != 26 || bytes[7] != 10) return false;
        int w = ((bytes[16]&255)<<24)|((bytes[17]&255)<<16)|((bytes[18]&255)<<8)|(bytes[19]&255);
        int h = ((bytes[20]&255)<<24)|((bytes[21]&255)<<16)|((bytes[22]&255)<<8)|(bytes[23]&255);
        return w > 0 && h > 0 && w <= 2048 && h <= 2048;
    }
}
