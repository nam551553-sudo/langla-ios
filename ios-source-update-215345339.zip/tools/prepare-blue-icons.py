"""Convert the supplied artwork to platform icon sizes without changing its design."""
from pathlib import Path
from PIL import Image, ImageOps
import sys

root = Path(__file__).resolve().parent.parent
source = Image.open(sys.argv[1]).convert('RGBA')
master = ImageOps.contain(source, (1024, 1024), Image.Resampling.LANCZOS)
canvas = Image.new('RGBA', (1024, 1024))
canvas.alpha_composite(master, ((1024-master.width)//2, (1024-master.height)//2))
icons = root/'resource/icons'
canvas.save(icons/'lang-la-blue.png')
for size in (16, 32, 48, 64, 128, 256, 512, 1024):
    canvas.resize((size, size), Image.Resampling.LANCZOS).save(icons/f'icon-{size}.png')
canvas.save(icons/'lang-la-blue.ico', sizes=[(s,s) for s in (16,32,48,64,128,256)])
# Login artwork is maintained separately from the application icon.
for density, size in [('mdpi',48),('hdpi',72),('xhdpi',96),('xxhdpi',144),('xxxhdpi',192)]:
    canvas.resize((size,size), Image.Resampling.LANCZOS).save(root/f'android/src/main/res/mipmap-{density}/ic_launcher.png')
opaque = Image.new('RGB', (1024,1024), (2,12,36))
opaque.paste(canvas, mask=canvas.getchannel('A'))
for name,size in {'Icon1024':1024,'Icon20@2x':40,'Icon20@3x':60,'Icon29@2x':58,
                  'Icon29@3x':87,'Icon40@2x':80,'Icon40@3x':120,'Icon60@2x':120,
                  'Icon60@3x':180,'Icon76':76,'Icon76@2x':152,'Icon83.5@2x':167}.items():
    opaque.resize((size,size),Image.Resampling.LANCZOS).save(root/f'ios/icons/{name}.png')
print('Prepared Blue icons for Android, iOS, PC, JAR and login logo.')
