# Cập nhật bản game

Xem HUONG-DAN-BUILD-ALL.md. Chạy BUILD-ALL.cmd (hoặc BUILD-RELEASE.cmd).
Cấu hình chung ở release-config.json; mặc định chép vào web XAMPP cục bộ.
PC/JAR kiểm tra version.json mỗi lần mở và tự tải core đã kiểm tra MD5/kích thước.
Android kiểm tra versionCode, tải APK và kiểm tra package/chữ ký trước khi cài.
Android yêu cầu người dùng xác nhận, và bản mới phải dùng cùng khóa ký.
Bản không có launcher, khác package hoặc khác khóa ký cần chuyển sang bộ mới một lần.
Giữ URL cũ hoạt động hoặc chuyển tiếp khi đổi VPS để các máy đã cài tìm được bản mới.
