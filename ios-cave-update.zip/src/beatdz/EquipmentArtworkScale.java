package beatdz;

import java.util.*;

/** Applies display dimensions once per downloaded pose table; source PNGs retain their detail. */
final class EquipmentArtworkScale {
    private static final Set<LangLa_jr[]> DONE = Collections.newSetFromMap(new WeakHashMap<LangLa_jr[],Boolean>());
    private static final Set<LangLa_ju> COSTUME_FRAMES = Collections.newSetFromMap(new WeakHashMap<LangLa_ju,Boolean>());
    private static final Map<Integer,float[]> GRIPS = new HashMap<Integer,float[]>();
    private static final Set<Integer> COSTUME_ICONS = new HashSet<Integer>();
    private static final Set<Integer> WEAPON_ICONS = new HashSet<Integer>();
    static void requestDensity(LangLa_fb request) {
        if(request.d!=null&&request.d.startsWith("iconChar/")&&WEAPON_ICONS.contains((int)request.a))
            request.e += "_weapon_art_20261127";
        if(request.d!=null&&request.d.startsWith("iconChar/")&&COSTUME_ICONS.contains((int)request.a)){
            request.sourceZoom=Math.min(4,Math.max(1,(int)Math.ceil(DataCenter.gI().zoomLevel*1.5)));
            request.e += "_hd150_z"+request.sourceZoom;
        }
    }
    static float bodyScale(LangLa_ju frame) { return COSTUME_FRAMES.contains(frame) ? 1.5f : 1f; }
    static float[] grip(int icon) { float[] point=GRIPS.get(icon);return point!=null?point:WeaponGrips.find(icon); }
    private static boolean costume(int part) { return part>=949&&part<=961 || part>=974&&part<=976 || part>=1084&&part<=1087; }
    static boolean armorBody(int part) { return part>=1089&&(part-1089)/107<3&&(part-1089)%107<9; }
    private static boolean weapon(int part) { return part>=986&&part<=1083 || part>=1098&&(part-1098)/107<3&&(part-1098)%107<98; }

    static synchronized void apply(DataCenter data) {
        if(data.F==null||DONE.contains(data.F))return;
        Map<Short,float[]> scales=new HashMap<Short,float[]>();
        Map<Short,int[]> original=new HashMap<Short,int[]>();
        for(int part=0;part<data.F.length;part++)if(data.F[part]!=null&&(costume(part)||weapon(part)))
            for(LangLa_ju frame:data.F[part].d)if(frame.a!=0){
                LangLa_et size=CostumeCape.spriteSize(data,frame.a);if(size==null)continue;
                original.put(frame.a,new int[]{size.d,size.e});float scale=costume(part)?1.5f:.8f;
                int width=Math.max(1,Math.round(size.d*scale)),height=Math.max(1,Math.round(size.e*scale));
                scales.put(frame.a,new float[]{width/(float)size.d,height/(float)size.e});
            }
        for(int part=0;part<data.F.length;part++)if(data.F[part]!=null&&(costume(part)||weapon(part)))
            for(LangLa_ju frame:data.F[part].d)if(frame.a!=0&&original.containsKey(frame.a)){
                if(costume(part)){
                    COSTUME_ICONS.add((int)frame.a);
                    if(COSTUME_FRAMES.add(frame)){frame.d=(byte)Math.round(frame.d*1.5f);frame.e=(byte)Math.round(frame.e*1.5f);}
                }else{
                    WEAPON_ICONS.add((int)frame.a);
                    float[] raw=WeaponGrips.find(frame.a),ratio=scales.get(frame.a);int[] size=original.get(frame.a);
                    if(raw==null)continue;
                    float[] next={raw[0]*ratio[0],raw[1]*ratio[1]};GRIPS.put((int)frame.a,next);
                    int angle=Utlis.a(frame.b),turn=(angle+360)%360;float sign=angle<0?-1:1;
                    double r=Math.toRadians(turn);
                    double oldX=sign*raw[0]*Math.cos(r)-raw[1]*Math.sin(r),oldY=sign*raw[0]*Math.sin(r)+raw[1]*Math.cos(r);
                    double newX=sign*next[0]*Math.cos(r)-next[1]*Math.sin(r),newY=sign*next[0]*Math.sin(r)+next[1]*Math.cos(r);
                    int oldHeight=angle%180==0?size[1]:size[0],newHeight=Math.round(oldHeight*(angle%180==0?ratio[1]:ratio[0]));
                    frame.d=(byte)Math.round(frame.d+oldX-newX);frame.e=(byte)Math.round(frame.e+oldY-newY+(newHeight-oldHeight)/2.0);
                }
            }
        Set<LangLa_et> resized=Collections.newSetFromMap(new IdentityHashMap<LangLa_et,Boolean>());
        for(Map.Entry<Short,float[]> row:scales.entrySet())for(Hashtable table:new Hashtable[]{data.ak,data.am}){
            LangLa_et size=(LangLa_et)table.get(row.getKey());if(size!=null&&resized.add(size)){
                size.d=(short)Math.max(1,Math.round(size.d*row.getValue()[0]));size.e=(short)Math.max(1,Math.round(size.e*row.getValue()[1]));
            }
        }
        DONE.add(data.F);
    }
}
